class Piece 

    def inititalize(color,board,pos)
        

        
    end
    
    def to_s
    end

    def empty?
    end

    private

    def move_into_check?(end_pos)

    end
    
end


