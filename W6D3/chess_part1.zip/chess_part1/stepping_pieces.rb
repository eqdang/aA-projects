class SteppingPieces #Knight/King

    def initialize
    end

    def symbol
    end

    protected

    def move_diffs
    end

end