class NullPieces

    def initialize
    end

    def moves

    end

    def symbol
    end

end