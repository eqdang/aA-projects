require_relative "board.rb"
 
# bishop/rook/queen

class SlidingPieces

    def inititalize

    end

    def symbol

    end

    def moves

    end

    def horizontal_dirs 

    end

    def diagonal_dirs

    end

protected

    def move_dirs
        
    end

    def grow_blocked_moves_dir(dx,dy)

    end

end
