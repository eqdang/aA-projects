require "byebug"

# Phase 0
require_relative '00_tree_node.rb'

class KnightPathFinder
    attr_accessor :considered_positions, :root_node
    
    def self.valid_moves(pos) 
        x,y = pos[0], pos[1]
        valids =  [ [x+2, y+1], [x+1, y+2], [x-1, y+2], 
                    [x-2, y+1], [x-2, y-1], [x-1, y-2], 
                    [x+1, y-2], [x+2, y-1] ]
        valids.select {|pair| pair[0] >= 0 && pair[1] >= 0 && pair[0] < 8 && pair[1] < 8}
    end
    
    def initialize(position)
        @root_node = PolyTreeNode.new(position)
        @considered_positions = []
        self.build_move_tree
    end

    def new_move_positions(pos)
        all_possible_moves = KnightPathFinder.valid_moves(pos)
        unconsidered_positions = []
        unconsidered_positions = all_possible_moves.reject { |pos| considered_positions.include?(pos) }
        self.considered_positions += unconsidered_positions
        unconsidered_positions
    end

    def build_move_tree
        queue = [@root_node]
        until queue.empty?
            parent = queue.shift              
            next_moves = new_move_positions(parent.value)  
            children = next_moves.map {|pos| PolyTreeNode.new(pos)} 
            children.each {|child| child.parent = parent }
            queue += children
        end
    end

    def find_path(end_pos)
        end_node = self.root_node.dfs(end_pos)
        trace_path_back(end_node)
    end

    def trace_path_back(end_node)
        path = [end_node.value]
        next_parent = end_node.parent
        until next_parent.nil?
            path.unshift(next_parent.value)
            next_parent = next_parent.parent 
        end
        path
    end

end