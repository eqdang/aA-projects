

class HumanPlayer

end